import { beforeEach, describe, expect, it, vi } from "vitest";
import { BOOKING_DRAFT_KEY, EMPTY_DRAFT, leerBorrador } from "@/lib/booking-draft";
import { validarDatos } from "@/components/taller/DatosForm";

describe("borrador y validación", () => {
  beforeEach(() => sessionStorage.clear());
  it("conserva servicio, fecha, hora y datos al leer el borrador de sesión", () => {
    const draft = { servicioId: "arreglo", fecha: "2026-11-16", hora: 540, datos: { nombre: "Andrés Gómez", celular: "3001234567", nota: "Bastilla" } };
    sessionStorage.setItem(BOOKING_DRAFT_KEY, JSON.stringify(draft));
    expect(leerBorrador()).toEqual(draft);
  });
  it("descarta borradores corruptos y no inventa valores", () => {
    sessionStorage.setItem(BOOKING_DRAFT_KEY, "invalid");
    expect(leerBorrador()).toEqual(EMPTY_DRAFT);
  });
  it("sigue exigiendo nombre completo y celular colombiano", () => {
    expect(validarDatos({ nombre: "Andrés", celular: "1234567890", nota: "" })).toHaveProperty("nombre");
    expect(validarDatos({ nombre: "Andrés Gómez", celular: "1234567890", nota: "" })).toHaveProperty("celular");
    expect(validarDatos({ nombre: "Andrés Gómez", celular: "3001234567", nota: "" })).toEqual({});
  });
});

describe("reservas sin recarga", () => {
  it("valida solapes al crear y mover, persiste y libera al cancelar", async () => {
    vi.resetModules();
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-11-16T08:00:00-05:00"));
    const { STORAGE_KEY, crearReserva, moverReserva, cancelarReserva } = await import("@/lib/storage");
    localStorage.setItem(STORAGE_KEY, "[]");
    try {
      const input = { servicioId: "arreglo", fecha: "2026-11-16", inicio: 540, nombre: "Andrés Gómez", celular: "3001234567", nota: "" };
      const primera = crearReserva(input);
      expect(primera.ok).toBe(true);
      if (!primera.ok) throw new Error(primera.error);
      expect(crearReserva(input).ok).toBe(false);
      const segunda = crearReserva({ ...input, inicio: 560 });
      expect(segunda.ok).toBe(true);
      if (!segunda.ok) throw new Error(segunda.error);
      expect(moverReserva(primera.reserva.id, input.fecha, 560).ok).toBe(false);
      expect(moverReserva(primera.reserva.id, input.fecha, 580).ok).toBe(true);
      expect(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]").find((r: { id: string }) => r.id === primera.reserva.id).inicio).toBe(580);
      cancelarReserva(primera.reserva.id);
      expect(crearReserva({ ...input, inicio: 580 }).ok).toBe(true);
      expect(JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]").find((r: { id: string }) => r.id === primera.reserva.id).estado).toBe("cancelada");
    } finally { vi.useRealTimers(); }
  });
});