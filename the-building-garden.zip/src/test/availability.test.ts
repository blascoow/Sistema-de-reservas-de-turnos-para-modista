import { describe, expect, it } from "vitest";
import { horasInicioValidas, motivoConflicto, type Reserva } from "@/lib/availability";
import { generarDatosEjemplo } from "@/lib/storage";
import { TALLER } from "@/config/taller";
import { esPasado, minutosAhora, toISODate, sumarDias, soloCelular, normalizarBusqueda } from "@/lib/format";
import { EMPTY_DRAFT, primerPasoIncompleto } from "@/lib/booking-draft";

// Lunes 16 de noviembre de 2026, 8:00 a. m.
const AHORA = new Date("2026-11-16T08:00:00-05:00");
const LUNES = "2026-11-16";
const r = (inicio: number, duracion: number, estado: Reserva["estado"] = "confirmada"): Reserva => ({
  id: `r${inicio}`, codigo: "HLV-TEST", servicioId: "x", fecha: LUNES, inicio, duracion,
  nombre: "A B", celular: "3001112233", nota: "", estado, creadaEn: "",
});

describe("disponibilidad", () => {
  it("usa America/Bogota aunque el instante UTC ya sea el día siguiente", () => {
    expect(TALLER.zonaHoraria).toBe("America/Bogota");
    const instante = new Date("2026-11-17T02:30:00Z");
    expect(toISODate(instante)).toBe("2026-11-16");
    expect(minutosAhora(instante)).toBe(21 * 60 + 30);
    expect(sumarDias(toISODate(instante), 1)).toBe("2026-11-17");
  });
  it("marca las franjas pasadas sin depender de la zona del dispositivo", () => {
    const ahora = new Date("2026-11-16T15:05:00-05:00");
    expect(esPasado(LUNES, 900, ahora)).toBe(true);
    expect(esPasado(LUNES, 920, ahora)).toBe(false);
    expect(esPasado("2026-11-13", 1080, ahora)).toBe(true);
  });
  it("el celular solo admite dígitos y espacios", () => {
    expect(soloCelular("300abc!+ 123-4567")).toBe("300 1234567");
  });
  it("la búsqueda ignora tildes y mayúsculas", () => {
    expect(normalizarBusqueda("Andrés Gómez").includes(normalizarBusqueda("ANDRES"))).toBe(true);
    expect(normalizarBusqueda("Andrés Gómez").includes("camilo")).toBe(false);
  });
  it("un acceso directo solo puede llegar al primer paso incompleto", () => {
    expect(primerPasoIncompleto(EMPTY_DRAFT, [], AHORA)).toBe(1);
    const d = { ...EMPTY_DRAFT, servicioId: "arreglo" };
    expect(primerPasoIncompleto(d, [], AHORA)).toBe(2);
    const conFecha = { ...d, fecha: LUNES };
    expect(primerPasoIncompleto(conFecha, [], AHORA)).toBe(3);
    const conHora = { ...conFecha, hora: 540 };
    expect(primerPasoIncompleto(conHora, [], AHORA)).toBe(4);
    expect(primerPasoIncompleto({ ...conHora, datos: { nombre: "Andrés Gómez", celular: "3001234567", nota: "" } }, [], AHORA)).toBe(5);
  });
  it("un servicio de 60 min no puede empezar a las 12:20 p. m. ni a las 5:20 p. m.", () => {
    const horas = horasInicioValidas(LUNES, 60, [], AHORA);
    expect(horas).not.toContain(12 * 60 + 20);
    expect(horas).not.toContain(17 * 60 + 20);
    expect(horas).toContain(12 * 60);
    expect(horas).toContain(17 * 60);
  });
  it("no permite solapar reservas", () => {
    expect(motivoConflicto({ fecha: LUNES, inicio: 560, duracion: 40 }, [r(580, 20)], AHORA)).not.toBeNull();
    expect(motivoConflicto({ fecha: LUNES, inicio: 540, duracion: 40 }, [r(580, 20)], AHORA)).toBeNull();
  });
  it("las canceladas liberan sus franjas", () => {
    expect(motivoConflicto({ fecha: LUNES, inicio: 580, duracion: 20 }, [r(580, 20, "cancelada")], AHORA)).toBeNull();
  });
  it("no ofrece horas pasadas de hoy ni fines de semana", () => {
    const tarde = new Date("2026-11-16T15:05:00-05:00");
    expect(horasInicioValidas(LUNES, 20, [], tarde)[0]).toBe(15 * 60 + 20);
    expect(horasInicioValidas("2026-11-21", 20, [], AHORA)).toEqual([]);
  });
  it("los datos de ejemplo no se solapan y ningún día queda lleno", () => {
    const seed = generarDatosEjemplo(AHORA);
    expect(seed.length).toBeGreaterThanOrEqual(15);
    const act = seed.filter((x) => x.estado === "confirmada");
    for (const x of act) expect(motivoConflicto(x, act, AHORA, x.id)).toBeNull();
    for (const f of new Set(act.map((x) => x.fecha))) expect(horasInicioValidas(f, 20, act, AHORA).length).toBeGreaterThan(0);
  });
});
