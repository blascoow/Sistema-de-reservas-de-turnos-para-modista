// Configuración central del taller: cambia aquí nombre, horario, servicios y clave.
export type Servicio = {
  id: string;
  nombre: string;
  duracion: number; // minutos, múltiplo de la franja
  descripcion: string;
};

export const TALLER = {
  nombre: "Taller Hilván",
  zonaHoraria: "America/Bogota",
  lema: "Arreglamos tu ropa con calma, a mano y como si fuera nuestra.",
  direccion: "Calle 63 # 13-27, Chapinero, Bogotá",
  telefono: "+57 310 555 0142",
  telefonoHref: "+573105550142",
  /** Clave del panel /admin. Solo protección de demo, no es seguridad real. */
  claveAdmin: "taller2026",
  /** Duración de cada franja en minutos. */
  franjaMinutos: 20,
  /** Días abiertos: 0 = domingo … 6 = sábado. */
  diasAbiertos: [1, 2, 3, 4, 5],
  /** Bloques de atención en minutos desde medianoche. */
  bloques: [
    { inicio: 9 * 60, fin: 13 * 60 },
    { inicio: 14 * 60, fin: 18 * 60 },
  ],
  diasReservables: 30,
  servicios: [
    {
      id: "arreglo",
      nombre: "Arreglo simple",
      duracion: 20,
      descripcion:
        "Bastillas, botones, cremalleras o una costura que se soltó. Traes la prenda, la medimos y te decimos cuándo estará lista.",
    },
    {
      id: "ajuste",
      nombre: "Ajuste de prenda completa",
      duracion: 40,
      descripcion:
        "Entallar un vestido, ajustar un traje o un jean de cintura a bota. Te la pruebas aquí y marcamos con alfileres.",
    },
    {
      id: "confeccion",
      nombre: "Confección a medida, primera prueba",
      duracion: 60,
      descripcion:
        "Para tu prenda hecha desde cero: tomamos medidas, revisamos tela y modelo, y hacemos la primera prueba del molde.",
    },
  ] satisfies Servicio[],
} as const;

export function getServicio(id: string): Servicio | undefined {
  return TALLER.servicios.find((s) => s.id === id);
}
