import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, LogOut, Plus, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Stitch } from "@/components/taller/SiteLayout";
import { ScheduleSelector } from "@/components/taller/Schedule";
import { DATOS_VACIOS, DatosForm, validarDatos, type Datos } from "@/components/taller/DatosForm";
import { ResumenTurno } from "@/components/taller/ResumenTurno";
import { MoverDialog } from "@/components/taller/MoverDialog";
import { ConfirmDialog } from "@/components/taller/ConfirmDialog";
import { TALLER, getServicio } from "@/config/taller";
import { esDiaAbierto, franjasDelDia, proximosDiasHabiles, type Reserva } from "@/lib/availability";
import { formatCelular, formatFecha, formatHora, minutosAhora, normalizarCelular, normalizarBusqueda, parseISODate, sumarDias, esPasado, toISODate } from "@/lib/format";
import { ADMIN_SESSION_KEY, cancelarReserva, crearReserva, restablecerDatos, useReservas } from "@/lib/storage";
import { useHeaderHeight } from "@/hooks/use-header-height";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: `Panel del taller · ${TALLER.nombre}` },
      { name: "description", content: "Agenda y gestión de turnos del taller." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: `Panel del taller · ${TALLER.nombre}` },
      { property: "og:description", content: "Agenda y gestión de turnos del taller." },
    ],
  }),
  component: Admin,
});

function Admin() {
  const [ok, setOk] = useState(false);
  useEffect(() => { setOk(sessionStorage.getItem(ADMIN_SESSION_KEY) === "1"); }, []);
  if (!ok) return <Login onOk={() => { sessionStorage.setItem(ADMIN_SESSION_KEY, "1"); setOk(true); }} />;
  return <Panel onSalir={() => { sessionStorage.removeItem(ADMIN_SESSION_KEY); setOk(false); toast.success("Sesión cerrada."); }} />;
}

function Login({ onOk }: { onOk: () => void }) {
  const [clave, setClave] = useState("");
  const [error, setError] = useState(false);
  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary px-4">
      <form className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-soft"
        onSubmit={(e) => { e.preventDefault(); if (clave === TALLER.claveAdmin) onOk(); else { setError(true); setClave(""); } }}>
        <h1 className="text-2xl font-semibold">Panel del taller</h1>
        <p className="mt-1 text-sm text-muted-foreground">Escribe la clave para ver la agenda.</p>
        <Stitch className="my-5" />
        <Label htmlFor="clave">Clave</Label>
        <Input id="clave" type="password" autoFocus className="mt-1.5 min-h-11 text-base" value={clave}
          aria-invalid={error} onChange={(e) => { setClave(e.target.value); setError(false); }} />
        {error && <p className="mt-2 text-sm text-destructive" role="alert">Clave incorrecta. Intenta de nuevo.</p>}
        <Button type="submit" variant="secondary" className="mt-4 w-full" disabled={!clave}>Entrar</Button>
        <Link to="/" className="mt-3 block py-2 text-center text-sm text-muted-foreground underline underline-offset-4">Ver la web pública</Link>
      </form>
    </div>
  );
}

const finDe = (r: Reserva) => r.inicio + r.duracion;
const momento = (r: Reserva) => `${r.fecha}-${String(r.inicio).padStart(4, "0")}`;

function Panel({ onSalir }: { onSalir: () => void }) {
  const reservas = useReservas();
  const headerRef = useHeaderHeight();
  const [ahora, setAhora] = useState(() => new Date());
  useEffect(() => { const timer = window.setInterval(() => setAhora(new Date()), 30000); return () => window.clearInterval(timer); }, []);
  const hoy = toISODate(ahora);
  const [dia, setDia] = useState(() => (esDiaAbierto(hoy) ? hoy : (proximosDiasHabiles(ahora, 1)[0] ?? hoy)));
  const [detalle, setDetalle] = useState<Reserva | null>(null);
  const [crear, setCrear] = useState(false);
  const [filtro, setFiltro] = useState("todos");
  const [q, setQ] = useState("");

  const activas = reservas.filter((r) => r.estado === "confirmada");
  const lunes = sumarDias(hoy, -((parseISODate(hoy).getUTCDay() + 6) % 7));
  const domingo = sumarDias(lunes, 6);
  const semana = activas.filter((r) => r.fecha >= lunes && r.fecha <= domingo).length;
  const deHoy = activas.filter((r) => r.fecha === hoy).length;
  const futuras = activas.filter((r) => r.fecha > hoy || (r.fecha === hoy && finDe(r) > minutosAhora(ahora))).sort((a, b) => momento(a).localeCompare(momento(b)));
  const proximo = futuras[0];

  const listado = useMemo(() => {
    const t = normalizarBusqueda(q); const dig = t.replace(/\D/g, "");
    return reservas
      .filter((r) => r.fecha >= hoy)
      .filter((r) => filtro === "todos" || r.servicioId === filtro)
      .filter((r) => !t || normalizarBusqueda(r.nombre).includes(t) || (dig.length > 0 && r.celular.includes(dig)))
      .sort((a, b) => momento(a).localeCompare(momento(b)));
  }, [reservas, filtro, q, hoy]);

  function moverDia(delta: number) {
    let d = dia;
    do d = sumarDias(d, delta); while (!esDiaAbierto(d));
    setDia(d);
  }

  const delDia = reservas.filter((r) => r.fecha === dia).sort((a, b) => a.inicio - b.inicio);
  const timeline = useMemo(() => {
    const items: ({ tipo: "libre"; inicio: number } | { tipo: "reserva"; r: Reserva })[] = [];
    const act = delDia.filter((r) => r.estado === "confirmada");
    for (const t of franjasDelDia()) {
      const r = act.find((x) => x.inicio === t);
      if (r) items.push({ tipo: "reserva", r });
      else if (!act.some((x) => t > x.inicio && t < finDe(x))) items.push({ tipo: "libre", inicio: t });
    }
    return items;
  }, [delDia]);
  const canceladasDia = delDia.filter((r) => r.estado === "cancelada");

  return (
    <div className="min-h-screen">
      <header ref={headerRef} className="sticky top-0 z-30 bg-secondary pt-[env(safe-area-inset-top)] text-secondary-foreground">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-2">
          <div><span className="font-serif text-lg font-semibold">{TALLER.nombre} · Panel</span><Link to="/" className="block py-1 text-xs underline underline-offset-4">Ver la web pública</Link></div>
          <Button variant="ghost" className="hover:bg-secondary-foreground/10 hover:text-secondary-foreground" onClick={onSalir}><LogOut /> Cerrar sesión</Button>
        </div>
      </header>

      <main className="safe-bottom mx-auto max-w-6xl space-y-8 px-4 py-6">
        <section className="grid gap-3 sm:grid-cols-3">
          <Stat titulo="Turnos de hoy" valor={String(deHoy)} />
          <Stat titulo="Turnos esta semana" valor={String(semana)} />
          <Stat titulo="Próximo turno" valor={proximo ? formatHora(proximo.inicio) : "—"}
            sub={proximo ? `${proximo.fecha === hoy ? "Hoy" : formatFecha(proximo.fecha)} · ${proximo.nombre}` : "No hay turnos pendientes"} />
        </section>

        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setCrear(true)}><Plus /> Nueva reserva</Button>
          <ConfirmDialog trigger={<Button variant="soft"><RotateCcw /> Restablecer datos de ejemplo</Button>}
            title="¿Restablecer los datos de ejemplo?" description="Se borrarán todas las reservas, incluidas las que hayas creado, y se cargarán de nuevo las de muestra."
            confirmText="Sí, restablecer" onConfirm={() => { restablecerDatos(); toast.success("Datos de ejemplo cargados de nuevo."); }} />
        </div>

        <section className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
          <div>
            <div className="mb-4 flex items-center justify-between gap-2">
              <Button variant="soft" size="icon" aria-label="Día anterior" onClick={() => moverDia(-1)}><ChevronLeft /></Button>
              <div className="text-center">
                <h2 className="text-xl font-semibold first-letter:uppercase">{formatFecha(dia)}</h2>
                {dia !== hoy && <button className="min-h-11 text-sm font-medium text-secondary underline underline-offset-4"
                  onClick={() => setDia(esDiaAbierto(hoy) ? hoy : (proximosDiasHabiles(ahora, 1)[0] ?? hoy))}>Ir a hoy</button>}
                {dia === hoy && <p className="text-sm text-muted-foreground">Hoy</p>}
              </div>
              <Button variant="soft" size="icon" aria-label="Día siguiente" onClick={() => moverDia(1)}><ChevronRight /></Button>
            </div>
            <ol className="space-y-1.5">
              {timeline.map((it, i) => {
                const pasoDescanso = i > 0 && it.tipo === "libre" && it.inicio === TALLER.bloques[1]?.inicio;
                const pasado = esPasado(dia, it.tipo === "libre" ? it.inicio : it.r.inicio, ahora);
                return (
                  <li className={pasado ? "opacity-50" : undefined} key={it.tipo === "libre" ? `l${it.inicio}` : it.r.id}>
                    {pasoDescanso && <div className="my-3 flex items-center gap-3 text-xs text-muted-foreground"><Stitch className="flex-1" />Almuerzo<Stitch className="flex-1" /></div>}
                    {it.tipo === "libre" ? (
                      <div className="flex min-h-11 items-center gap-3 rounded-xl border border-dashed border-border px-3 text-sm text-muted-foreground">
                        <span className="w-20 font-medium">{formatHora(it.inicio)}</span> {pasado ? "Pasado" : "Libre"}
                      </div>
                    ) : (
                      <Button variant="ghost" disabled={pasado} onClick={() => setDetalle(it.r)} className="block h-auto whitespace-normal w-full rounded-xl border-l-4 border-secondary bg-card p-3 text-left shadow-soft hover:bg-petrol-soft">
                        <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                          <span className="font-semibold">{formatHora(it.r.inicio)} – {formatHora(finDe(it.r))}</span>
                          <span className="text-sm text-secondary">{getServicio(it.r.servicioId)?.nombre}</span>
                        </div>
                        {pasado && <span className="text-xs text-muted-foreground">Pasado</span>}
                        <p className="mt-1">{it.r.nombre} · <span className="text-muted-foreground">{formatCelular(it.r.celular)}</span></p>
                        {it.r.nota && <p className="mt-0.5 text-sm text-muted-foreground">{it.r.nota}</p>}
                      </Button>
                    )}
                  </li>
                );
              })}
            </ol>
            {canceladasDia.length > 0 && (
              <div className="mt-4 space-y-1.5">
                <h3 className="text-sm font-semibold text-muted-foreground">Canceladas este día</h3>
                {canceladasDia.map((r) => (
                  <button disabled={esPasado(dia, r.inicio, ahora)} key={r.id} onClick={() => setDetalle(r)} className="flex min-h-11 w-full items-center justify-between rounded-xl bg-muted px-3 text-left text-sm line-through decoration-muted-foreground/60">
                    <span>{formatHora(r.inicio)} · {r.nombre}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <h2 className="mb-4 text-xl font-semibold">Próximas reservas</h2>
            <div className="mb-3 flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input className="min-h-11 bg-card pl-9 text-base" placeholder="Buscar por nombre o celular" value={q} onChange={(e) => setQ(e.target.value)} />
              </div>
              <select value={filtro} onChange={(e) => setFiltro(e.target.value)} aria-label="Filtrar por servicio"
                className="min-h-11 rounded-md border border-input bg-card px-3 text-sm">
                <option value="todos">Todos los servicios</option>
                {TALLER.servicios.map((s) => <option key={s.id} value={s.id}>{s.nombre}</option>)}
              </select>
            </div>
            <ul className="space-y-1.5">
              {listado.length === 0 && <li className="rounded-xl bg-card p-4 text-muted-foreground">No hay reservas que coincidan.</li>}
              {listado.map((r) => (
                <li key={r.id}>
                  <button onClick={() => setDetalle(r)} className={cn("flex w-full items-center justify-between gap-3 rounded-xl bg-card px-3 py-2.5 text-left hover:bg-accent", r.estado === "cancelada" && "opacity-60")}>
                    <span>
                      <span className="block font-medium">{r.nombre}</span>
                      <span className="block text-sm text-muted-foreground first-letter:uppercase">{formatFecha(r.fecha)} · {formatHora(r.inicio)}</span>
                    </span>
                    <span className={cn("shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold", r.estado === "cancelada" ? "bg-muted" : "bg-petrol-soft text-secondary")}>
                      {r.estado === "cancelada" ? "Cancelada" : `${r.duracion} min`}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>

      <Dialog open={!!detalle} onOpenChange={(o) => !o && setDetalle(null)}>
        {detalle && <DetalleContent id={detalle.id} cerrar={() => setDetalle(null)} />}
      </Dialog>
      <CrearDialog open={crear} onOpenChange={setCrear} />
    </div>
  );
}

function Stat({ titulo, valor, sub }: { titulo: string; valor: string; sub?: string }) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-soft">
      <p className="text-sm text-muted-foreground">{titulo}</p>
      <p className="font-serif text-3xl font-semibold text-secondary">{valor}</p>
      {sub && <p className="truncate text-sm text-muted-foreground first-letter:uppercase">{sub}</p>}
    </div>
  );
}

function DetalleContent({ id, cerrar }: { id: string; cerrar: () => void }) {
  const r = useReservas().find((x) => x.id === id);
  if (!r) return null;
  return (
    <DialogContent className="max-h-[90dvh] overflow-y-auto bg-card">
      <DialogHeader>
        <DialogTitle className="font-serif">Reserva {r.codigo}</DialogTitle>
        <DialogDescription>{r.estado === "cancelada" ? "Esta reserva está cancelada." : "Reserva confirmada."}</DialogDescription>
      </DialogHeader>
      <ResumenTurno servicioId={r.servicioId} fecha={r.fecha} inicio={r.inicio} nombre={r.nombre} celular={r.celular} nota={r.nota} />
      <div className="flex flex-col gap-2 sm:flex-row">
        <Button asChild variant="soft" className="flex-1"><a href={`tel:+57${r.celular}`}>Llamar</a></Button>
        {r.estado === "confirmada" && (
          <>
            <MoverDialog reserva={r} trigger={<Button variant="secondary" className="flex-1">Mover</Button>} />
            <ConfirmDialog trigger={<Button variant="destructive" className="flex-1">Cancelar</Button>}
              title={`¿Cancelar el turno de ${r.nombre}?`} description="El horario quedará libre para otra persona."
              confirmText="Sí, cancelar" onConfirm={() => { cancelarReserva(r.id); toast.success("Reserva cancelada."); cerrar(); }} />
          </>
        )}
      </div>
    </DialogContent>
  );
}

function CrearDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const reservas = useReservas();
  const [servicioId, setServicioId] = useState<string>(TALLER.servicios[0]?.id ?? "");
  const [fecha, setFecha] = useState<string | null>(null);
  const [hora, setHora] = useState<number | null>(null);
  const [datos, setDatos] = useState<Datos>(DATOS_VACIOS);
  const [tocados, setTocados] = useState<Partial<Record<keyof Datos, boolean>>>({});
  const servicio = getServicio(servicioId) ?? TALLER.servicios[0];
  const valido = !!servicio && fecha && hora !== null && Object.keys(validarDatos(datos)).length === 0;

  useEffect(() => { if (open) { setFecha(null); setHora(null); setDatos(DATOS_VACIOS); setTocados({}); } }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto bg-card">
        <DialogHeader>
          <DialogTitle className="font-serif">Nueva reserva</DialogTitle>
          <DialogDescription>Para clientes que llaman o pasan por el taller.</DialogDescription>
        </DialogHeader>
        <div className="space-y-1.5">
          <Label htmlFor="servicio">Servicio</Label>
          <select id="servicio" value={servicioId} onChange={(e) => { setServicioId(e.target.value); setHora(null); }}
            className="min-h-11 w-full rounded-md border border-input bg-card px-3 text-base">
            {TALLER.servicios.map((s) => <option key={s.id} value={s.id}>{s.nombre} ({s.duracion} min)</option>)}
          </select>
        </div>
        <ScheduleSelector duracion={servicio?.duracion ?? TALLER.franjaMinutos} reservas={reservas} fecha={fecha} hora={hora}
          onFecha={(f) => { setFecha(f); setHora(null); }} onHora={setHora} />
        <DatosForm value={datos} onChange={setDatos} tocados={tocados} onBlur={(k) => setTocados((t) => ({ ...t, [k]: true }))} />
        <Button disabled={!valido} onClick={() => {
          const celular = normalizarCelular(datos.celular);
          if (!fecha || hora === null || !celular) return;
          const res = crearReserva({ servicioId, fecha, inicio: hora, nombre: datos.nombre, celular, nota: datos.nota });
          if (!res.ok) { toast.error(res.error); setHora(null); return; }
          toast.success(`Reserva ${res.reserva.codigo} creada. Simulación: se habría enviado la confirmación al cliente.`);
          onOpenChange(false);
        }}>Crear reserva</Button>
      </DialogContent>
    </Dialog>
  );
}
