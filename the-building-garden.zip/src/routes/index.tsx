import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout, Stitch } from "@/components/taller/SiteLayout";
import { TALLER } from "@/config/taller";
import { formatHora } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: `${TALLER.nombre} · Taller de costura en Bogotá` },
      { name: "description", content: "Arreglos, ajustes y confección a medida. Mira la disponibilidad real y reserva tu turno en línea." },
      { property: "og:title", content: `${TALLER.nombre} · Reserva tu turno` },
      { property: "og:description", content: "Arreglos, ajustes y confección a medida en Bogotá. Reserva tu turno en línea." },
    ],
  }),
  component: Inicio,
});

const PASOS = [
  ["Elige el servicio", "Arreglo, ajuste o confección: cada uno tiene su tiempo."],
  ["Escoge día y hora", "Solo ves los horarios que de verdad están libres."],
  ["Confirma y listo", "Te damos un código para cambiar o cancelar cuando quieras."],
];

function Inicio() {
  const horario = TALLER.bloques.map((b) => `${formatHora(b.inicio)} a ${formatHora(b.fin)}`).join(" y ");
  return (
    <SiteLayout>
      <section className="py-6 text-center sm:py-12">
        <p className="mb-3 text-sm font-medium uppercase tracking-widest text-secondary">Taller de costura de barrio</p>
        <h1 className="mx-auto max-w-2xl text-4xl font-semibold leading-tight sm:text-6xl">{TALLER.nombre}</h1>
        <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">{TALLER.lema}</p>
        <Stitch className="mx-auto my-8 w-32" />
        <Button asChild size="lg" className="w-full max-w-xs">
          <Link to="/reservar" search={{ paso: 1 }}>Reservar turno</Link>
        </Button>
        <p className="mt-3 text-sm text-muted-foreground">
          ¿Ya tienes turno? <Link to="/mi-turno" search={{ codigo: "", celular: "" }} className="font-medium text-secondary underline underline-offset-4">Consúltalo aquí</Link>
        </p>
      </section>

      <section className="mt-6">
        <h2 className="mb-5 text-2xl font-semibold">Cómo funciona</h2>
        <ol className="grid gap-3 sm:grid-cols-3">
          {PASOS.map(([t, d], i) => (
            <li key={t} className="rounded-2xl bg-card p-5 shadow-soft">
              <span className="stitch-border flex h-10 w-10 items-center justify-center rounded-full font-serif text-lg font-semibold text-primary">{i + 1}</span>
              <h3 className="mt-3 text-lg font-semibold">{t}</h3>
              <p className="mt-1 text-muted-foreground">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-12">
        <h2 className="mb-5 text-2xl font-semibold">Servicios</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          {TALLER.servicios.map((s) => (
            <article key={s.id} className="flex flex-col rounded-2xl border border-border bg-card p-5">
              <span className="w-fit rounded-full bg-petrol-soft px-3 py-1 text-xs font-semibold text-secondary">{s.duracion} minutos</span>
              <h3 className="mt-3 text-lg font-semibold">{s.nombre}</h3>
              <p className="mt-1 flex-1 text-muted-foreground">{s.descripcion}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-12 grid gap-3 rounded-2xl bg-secondary p-6 text-secondary-foreground sm:grid-cols-3">
        <div className="flex gap-3"><Clock className="mt-0.5 h-5 w-5 shrink-0" /><div><p className="font-semibold">Horario</p><p className="opacity-90">Lunes a viernes, de {horario} Sábados y domingos cerrado.</p></div></div>
        <div className="flex gap-3"><MapPin className="mt-0.5 h-5 w-5 shrink-0" /><div><p className="font-semibold">Dirección</p><p className="opacity-90">{TALLER.direccion}</p></div></div>
        <div className="flex gap-3"><Phone className="mt-0.5 h-5 w-5 shrink-0" /><div><p className="font-semibold">Teléfono</p><a href={`tel:${TALLER.telefonoHref}`} className="opacity-90 underline underline-offset-4">{TALLER.telefono}</a></div></div>
      </section>
    </SiteLayout>
  );
}
