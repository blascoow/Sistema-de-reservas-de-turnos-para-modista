import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Check, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout, Stitch } from "@/components/taller/SiteLayout";
import { DayPicker, TimePicker, useDiasDisponibles } from "@/components/taller/Schedule";
import { DATOS_VACIOS, DatosForm, validarDatos, type Datos } from "@/components/taller/DatosForm";
import { ResumenTurno } from "@/components/taller/ResumenTurno";
import { TALLER, getServicio } from "@/config/taller";
import { crearReserva, useReservas } from "@/lib/storage";
import { formatFecha, normalizarCelular } from "@/lib/format";
import type { Reserva } from "@/lib/availability";
import { BOOKING_DRAFT_KEY, EMPTY_DRAFT, leerBorrador, primerPasoIncompleto } from "@/lib/booking-draft";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/reservar")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({ paso: Number.isFinite(Number(search["paso"])) ? Number(search["paso"]) : 1 }),
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: `Reservar turno · ${TALLER.nombre}` },
      { name: "description", content: "Elige servicio, día y hora y reserva tu turno en el taller en un minuto." },
      { property: "og:title", content: `Reservar turno · ${TALLER.nombre}` },
      { property: "og:description", content: "Elige servicio, día y hora y reserva tu turno en el taller." },
    ],
  }),
  component: Reservar,
});

const PASOS = ["Servicio", "Fecha", "Hora", "Datos", "Confirmar"];

function Reservar() {
  const reservas = useReservas();
  const { paso: solicitado } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [listo, setListo] = useState(false);
  const [servicioId, setServicioId] = useState<string | null>(null);
  const [fecha, setFecha] = useState<string | null>(null);
  const [hora, setHora] = useState<number | null>(null);
  const [datos, setDatos] = useState<Datos>(DATOS_VACIOS);
  const [tocados, setTocados] = useState<Partial<Record<keyof Datos, boolean>>>({});
  const [hecha, setHecha] = useState<Reserva | null>(null);

  useEffect(() => {
    const d = leerBorrador();
    setServicioId(d.servicioId); setFecha(d.fecha); setHora(d.hora); setDatos(d.datos); setListo(true);
  }, []);
  useEffect(() => {
    if (!listo || hecha) return;
    try { sessionStorage.setItem(BOOKING_DRAFT_KEY, JSON.stringify({ servicioId, fecha, hora, datos })); } catch { /* Storage may be unavailable. */ }
  }, [listo, hecha, servicioId, fecha, hora, datos]);
  const limite = primerPasoIncompleto({ servicioId, fecha, hora, datos }, reservas, new Date());
  const paso = Math.min(Math.max(1, Math.trunc(solicitado)), limite) - 1;
  useEffect(() => {
    if (listo && !hecha && solicitado !== paso + 1) void navigate({ search: { paso: paso + 1 }, replace: true });
  }, [listo, hecha, solicitado, paso, navigate]);
  const setPaso = (p: number) => { void navigate({ search: { paso: p + 1 } }); };
  function reiniciar() {
    sessionStorage.removeItem(BOOKING_DRAFT_KEY);
    setServicioId(EMPTY_DRAFT.servicioId); setFecha(null); setHora(null); setDatos(DATOS_VACIOS); setTocados({}); setHecha(null);
    void navigate({ search: { paso: 1 } });
  }
  const servicio = servicioId ? getServicio(servicioId) : undefined;
  const dias = useDiasDisponibles(servicio?.duracion ?? TALLER.franjaMinutos, reservas);
  const horas = dias.find((d) => d.fecha === fecha)?.horas ?? [];
  const siguienteConHueco = dias.find((d) => d.fecha > (fecha ?? "") && d.horas.length);
  const datosOk = Object.keys(validarDatos(datos)).length === 0;

  const puedeSeguir = [!!servicioId, !!fecha, hora !== null && horas.includes(hora), datosOk, true][paso];

  function confirmar() {
    const celular = normalizarCelular(datos.celular);
    if (!servicioId || !fecha || hora === null || !celular || !datosOk) return;
    const res = crearReserva({ servicioId, fecha, inicio: hora, nombre: datos.nombre, celular, nota: datos.nota });
    if (!res.ok) {
      toast.error(res.error + " Elige otra hora, por favor.");
      setHora(null);
      setPaso(2);
      return;
    }
    toast.success("¡Tu turno quedó reservado!");
    sessionStorage.removeItem(BOOKING_DRAFT_KEY);
    setHecha(res.reserva);
  }

  if (!listo) return null;
  if (hecha) return <Confirmacion r={hecha} onOtra={reiniciar} />;

  return (
    <SiteLayout>
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-semibold">Reserva tu turno</h1>
        <ol className="mt-5 flex gap-1.5" aria-label="Progreso">
          {PASOS.map((p, i) => (
            <li key={p} className="flex-1">
              <div className={cn("h-1.5 rounded-full", i <= paso ? "bg-primary" : "bg-muted")} />
              <span className={cn("mt-1.5 hidden text-xs sm:block", i === paso ? "font-semibold" : "text-muted-foreground")}>{p}</span>
            </li>
          ))}
        </ol>
        <p className="mt-2 text-sm text-muted-foreground sm:hidden">Paso {paso + 1} de 5 · {PASOS[paso]}</p>
        <Stitch className="my-6" />

        {paso === 0 && (
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">¿Qué necesitas?</h2>
            {TALLER.servicios.map((s) => (
              <Button variant="ghost" key={s.id} type="button" aria-pressed={servicioId === s.id}
                onClick={() => { if (s.id !== servicioId) { setServicioId(s.id); setHora(null); } }}
                className={cn("block h-auto whitespace-normal w-full rounded-2xl border-2 bg-card p-4 text-left transition-colors",
                  servicioId === s.id ? "border-secondary" : "border-transparent shadow-soft hover:border-border")}>
                <div className="flex items-center justify-between gap-3">
                  <span className="font-serif text-lg font-semibold">{s.nombre}</span>
                  <span className="shrink-0 rounded-full bg-petrol-soft px-2.5 py-1 text-xs font-semibold text-secondary">{s.duracion} min</span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{s.descripcion}</p>
              </Button>
            ))}
          </div>
        )}

        {paso === 1 && (
          <div>
            <h2 className="mb-1 text-xl font-semibold">Elige el día</h2>
            <p className="mb-4 text-sm text-muted-foreground">Próximos {TALLER.diasReservables} días hábiles para {servicio?.nombre.toLowerCase()}.</p>
            <DayPicker dias={dias} value={fecha} onChange={(f) => { setFecha(f); setHora(null); }} />
          </div>
        )}

        {paso === 2 && fecha && (
          <div>
            <h2 className="mb-1 text-xl font-semibold">Elige la hora</h2>
            <p className="mb-4 text-sm text-muted-foreground first-letter:uppercase">{formatFecha(fecha)} · {servicio?.duracion} minutos</p>
            {horas.length ? (
              <TimePicker horas={horas} value={hora} onChange={setHora} />
            ) : (
              <div className="rounded-2xl bg-card p-5">
                <p>Uy, ese día ya no nos queda espacio para este servicio.</p>
                {siguienteConHueco && (
                  <Button variant="secondary" className="mt-3" onClick={() => { setFecha(siguienteConHueco.fecha); setHora(null); }}>
                    Ver el {formatFecha(siguienteConHueco.fecha)}
                  </Button>
                )}
              </div>
            )}
          </div>
        )}

        {paso === 3 && (
          <div>
            <h2 className="mb-4 text-xl font-semibold">Tus datos</h2>
            <DatosForm value={datos} onChange={setDatos} tocados={tocados} onBlur={(k) => setTocados((t) => ({ ...t, [k]: true }))} />
          </div>
        )}

        {paso === 4 && servicioId && fecha && hora !== null && normalizarCelular(datos.celular) && (
          <div>
            <h2 className="mb-4 text-xl font-semibold">Revisa y confirma</h2>
            <ResumenTurno servicioId={servicioId} fecha={fecha} inicio={hora} nombre={datos.nombre} celular={normalizarCelular(datos.celular) ?? ""} nota={datos.nota} />
          </div>
        )}

        <div className="safe-bottom sticky bottom-0 -mx-4 mt-8 flex gap-3 border-t border-border bg-background/95 px-4 pt-4 backdrop-blur">
          {paso > 0 && (
            <Button variant="soft" onClick={() => setPaso(paso - 1)}><ArrowLeft /> Atrás</Button>
          )}
          {paso < 4 ? (
            <Button className="flex-1" disabled={!puedeSeguir}
              onClick={() => { if (paso === 3) setTocados({ nombre: true, celular: true }); setPaso(paso + 1); }}>
              Continuar
            </Button>
          ) : (
            <Button className="flex-1" onClick={confirmar}><Check /> Confirmar turno</Button>
          )}
        </div>
      </div>
    </SiteLayout>
  );
}

function Confirmacion({ r, onOtra }: { r: Reserva; onOtra: () => void }) {
  return (
    <SiteLayout onReservar={onOtra}>
      <div className="mx-auto max-w-xl text-center">
        <div className="stitch-border mx-auto flex h-16 w-16 items-center justify-center rounded-full text-primary"><Check className="h-7 w-7" /></div>
        <h1 className="mt-4 text-3xl font-semibold">¡Listo, {r.nombre.split(" ")[0]}!</h1>
        <p className="mt-2 text-muted-foreground">Te esperamos en el taller. Guarda este código:</p>
        <p className="mx-auto mt-4 w-fit rounded-2xl bg-card px-6 py-3 font-mono text-3xl font-semibold tracking-widest text-secondary shadow-soft">{r.codigo}</p>
        <p className="mt-2 text-sm text-muted-foreground">Lo necesitas, junto con tu celular, para cambiar o cancelar tu turno.</p>
        <div className="mt-6 text-left">
          <ResumenTurno servicioId={r.servicioId} fecha={r.fecha} inicio={r.inicio} nombre={r.nombre} celular={r.celular} nota={r.nota} />
        </div>
        <div className="mt-6 flex flex-col gap-3">
          <Button variant="secondary" onClick={onOtra}>Hacer otra reserva</Button>
          <Button variant="secondary" onClick={() => toast.info("Esto es una demo: no se envía ningún WhatsApp. En la versión real te llegaría un recordatorio el día anterior.")}>
            <MessageCircle /> Recibir recordatorio por WhatsApp
          </Button>
          <Button asChild variant="soft"><Link to="/mi-turno" search={{ codigo: r.codigo, celular: r.celular }}>Gestionar mi turno</Link></Button>
          <Button asChild variant="link"><Link to="/">Volver al inicio</Link></Button>
        </div>
      </div>
    </SiteLayout>
  );
}
