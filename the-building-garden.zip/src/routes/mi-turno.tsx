import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SiteLayout, Stitch } from "@/components/taller/SiteLayout";
import { ResumenTurno } from "@/components/taller/ResumenTurno";
import { MoverDialog } from "@/components/taller/MoverDialog";
import { ConfirmDialog } from "@/components/taller/ConfirmDialog";
import { TALLER } from "@/config/taller";
import { normalizarCelular, soloCelular, esPasado } from "@/lib/format";
import { cancelarReserva, useReservas } from "@/lib/storage";

export const Route = createFileRoute("/mi-turno")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    codigo: typeof search["codigo"] === "string" ? search["codigo"] : "",
    celular: typeof search["celular"] === "string" ? search["celular"] : "",
  }),
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: `Mi turno · ${TALLER.nombre}` },
      { name: "description", content: "Consulta, cambia o cancela tu turno con tu código de reserva y tu celular." },
      { property: "og:title", content: `Mi turno · ${TALLER.nombre}` },
      { property: "og:description", content: "Consulta, cambia o cancela tu turno en el taller." },
    ],
  }),
  component: MiTurno,
});

function MiTurno() {
  const reservas = useReservas();
  const search = Route.useSearch();
  const [codigo, setCodigo] = useState("");
  const [celular, setCelular] = useState("");
  const [buscado, setBuscado] = useState<{ codigo: string; celular: string } | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { setCodigo(search["codigo"]); setCelular(soloCelular(search["celular"])); }, [search["codigo"], search["celular"]]);

  const reserva = buscado ? reservas.find((r) => r.codigo === buscado.codigo && r.celular === buscado.celular) : undefined;
  const pasada = reserva && esPasado(reserva.fecha, reserva.inicio);

  function buscar(e: React.FormEvent) {
    e.preventDefault();
    const cel = normalizarCelular(celular);
    const cod = codigo.trim().toUpperCase();
    if (!cod || !cel) return setError("Revisa el código (ej. HLV-4K7P) y un celular de 10 dígitos que empiece por 3.");
    if (!reservas.some((r) => r.codigo === cod && r.celular === cel)) {
      setBuscado(null);
      return setError("No encontramos un turno con ese código y ese celular. Revisa los datos.");
    }
    setError("");
    setBuscado({ codigo: cod, celular: cel });
  }

  return (
    <SiteLayout>
      <div className="mx-auto max-w-xl">
        <h1 className="text-3xl font-semibold">Mi turno</h1>
        <p className="mt-2 text-muted-foreground">Escribe el código que te dimos al reservar y tu celular.</p>
        <form onSubmit={buscar} className="mt-6 space-y-4 rounded-2xl bg-card p-5 shadow-soft">
          <div className="space-y-1.5">
            <Label htmlFor="codigo">Código de reserva</Label>
            <Input id="codigo" className="min-h-11 font-mono text-base uppercase" placeholder="HLV-4K7P" value={codigo} onChange={(e) => setCodigo(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cel">Celular</Label>
            <Input id="cel" type="tel" inputMode="numeric" className="min-h-11 text-base" placeholder="300 123 4567" value={celular} onChange={(e) => setCelular(soloCelular(e.target.value))} />
          </div>
          {error && <p className="text-sm text-destructive" role="alert">{error}</p>}
          <Button type="submit" className="w-full" disabled={!codigo.trim() || !celular.trim()}>Buscar mi turno</Button>
        </form>

        {reserva && (
          <section className="mt-8">
            <Stitch className="mb-6" />
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-semibold">Turno {reserva.codigo}</h2>
              <span className={reserva.estado === "cancelada" ? "rounded-full bg-muted px-3 py-1 text-xs font-semibold" : "rounded-full bg-petrol-soft px-3 py-1 text-xs font-semibold text-secondary"}>
                {reserva.estado === "cancelada" ? "Cancelado" : pasada ? "Ya pasó" : "Confirmado"}
              </span>
            </div>
            <ResumenTurno servicioId={reserva.servicioId} fecha={reserva.fecha} inicio={reserva.inicio} nombre={reserva.nombre} celular={reserva.celular} nota={reserva.nota} />
            {reserva.estado === "confirmada" && !pasada ? (
              <div className="mt-4 flex flex-col gap-3 sm:flex-row">
                <MoverDialog reserva={reserva} trigger={<Button variant="secondary" className="flex-1">Cambiar fecha u hora</Button>} />
                <ConfirmDialog trigger={<Button variant="soft" className="flex-1">Cancelar turno</Button>}
                  title="¿Cancelar tu turno?" description="Liberaremos ese horario para otra persona. Si cambias de idea, tendrás que reservar de nuevo."
                  confirmText="Sí, cancelar" onConfirm={() => { cancelarReserva(reserva.id); toast.success("Tu turno fue cancelado."); }} />
              </div>
            ) : (
              <Button asChild className="mt-4 w-full"><Link to="/reservar" search={{ paso: 1 }}>Reservar un nuevo turno</Link></Button>
            )}
          </section>
        )}
      </div>
    </SiteLayout>
  );
}
