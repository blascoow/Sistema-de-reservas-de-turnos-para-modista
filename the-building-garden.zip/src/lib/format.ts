import { TALLER } from "@/config/taller";

const DIAS = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
const MESES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];

export function toISODate(d: Date): string {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: TALLER.zonaHoraria, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(d);
  const part = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  return `${part("year")}-${part("month")}-${part("day")}`;
}

export function parseISODate(iso: string): Date {
  const [y = 0, m = 1, d = 1] = iso.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

/** "martes 18 de noviembre" */
export function formatFecha(iso: string): string {
  const d = parseISODate(iso);
  return `${DIAS[d.getUTCDay()] ?? ""} ${d.getUTCDate()} de ${MESES[d.getUTCMonth()] ?? ""}`;
}

export function formatDiaCorto(iso: string) {
  const d = parseISODate(iso);
  return { dia: (DIAS[d.getUTCDay()] ?? "").slice(0, 3), num: d.getUTCDate(), mes: (MESES[d.getUTCMonth()] ?? "").slice(0, 3) };
}

/** 560 -> "9:20 a. m." */
export function formatHora(min: number): string {
  const h24 = Math.floor(min / 60);
  const m = min % 60;
  const sufijo = h24 >= 12 ? "p. m." : "a. m.";
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${sufijo}`;
}

export function minutosAhora(d: Date): number {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: TALLER.zonaHoraria, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(d);
  return Number(parts.find((p) => p.type === "hour")?.value ?? 0) * 60 + Number(parts.find((p) => p.type === "minute")?.value ?? 0);
}

export function formatCelular(cel: string): string {
  const c = cel.replace(/\D/g, "");
  return `+57 ${c.slice(0, 3)} ${c.slice(3, 6)} ${c.slice(6)}`;
}

/** Celular colombiano: 10 dígitos que empiezan por 3 (acepta prefijo +57). */
export function normalizarCelular(input: string): string | null {
  let c = input.replace(/\D/g, "");
  if (c.length === 12 && c.startsWith("57")) c = c.slice(2);
  return /^3\d{9}$/.test(c) ? c : null;
}

/** Calendar arithmetic never interprets a shop date in the device timezone. */
export function sumarDias(fecha: string, cantidad: number): string {
  const d = parseISODate(fecha);
  d.setUTCDate(d.getUTCDate() + cantidad);
  return d.toISOString().slice(0, 10);
}
export function esPasado(fecha: string, inicio: number, ahora = new Date()): boolean {
  const hoy = toISODate(ahora);
  return fecha < hoy || (fecha === hoy && inicio <= minutosAhora(ahora));
}
export function soloCelular(value: string): string { return value.replace(/[^0-9 ]/g, ""); }
export function normalizarBusqueda(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
