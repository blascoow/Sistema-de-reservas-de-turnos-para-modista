import { useSyncExternalStore } from "react";
import { TALLER, getServicio } from "@/config/taller";
import { motivoConflicto, proximosDiasHabiles, type Reserva } from "@/lib/availability";

export const STORAGE_KEY = "hilvan_v1_reservas";
export const ADMIN_SESSION_KEY = "hilvan_v1_admin";

let cache: Reserva[] | null = null;
const listeners = new Set<() => void>();
const EMPTY: Reserva[] = [];

function emit() {
  listeners.forEach((l) => l());
}

function leer(): Reserva[] {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return (cache = parsed);
    }
  } catch (e) {
    console.warn("No se pudieron leer las reservas guardadas", e);
  }
  const seed = generarDatosEjemplo(new Date());
  escribir(seed);
  return seed;
}

function escribir(reservas: Reserva[]) {
  cache = reservas;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reservas));
  } catch (e) {
    console.warn("No se pudieron guardar las reservas", e);
  }
  emit();
}

export function useReservas(): Reserva[] {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      const onStorage = (e: StorageEvent) => {
        if (e.key === STORAGE_KEY) {
          cache = null;
          cb();
        }
      };
      window.addEventListener("storage", onStorage);
      return () => {
        listeners.delete(cb);
        window.removeEventListener("storage", onStorage);
      };
    },
    leer,
    () => EMPTY,
  );
}

const ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function generarCodigo(existentes: Set<string>): string {
  let c = "";
  do {
    c = "HLV-" + Array.from({ length: 4 }, () => ALFABETO[Math.floor(Math.random() * ALFABETO.length)]).join("");
  } while (existentes.has(c));
  return c;
}

type Resultado = { ok: true; reserva: Reserva } | { ok: false; error: string };

export function crearReserva(input: {
  servicioId: string;
  fecha: string;
  inicio: number;
  nombre: string;
  celular: string;
  nota: string;
}): Resultado {
  const servicio = getServicio(input.servicioId);
  if (!servicio) return { ok: false, error: "Servicio no encontrado." };
  const actuales = leer();
  const error = motivoConflicto({ ...input, duracion: servicio.duracion }, actuales, new Date());
  if (error) return { ok: false, error };
  const reserva: Reserva = {
    id: crypto.randomUUID(),
    codigo: generarCodigo(new Set(actuales.map((r) => r.codigo))),
    servicioId: servicio.id,
    fecha: input.fecha,
    inicio: input.inicio,
    duracion: servicio.duracion,
    nombre: input.nombre.trim(),
    celular: input.celular,
    nota: input.nota.trim(),
    estado: "confirmada",
    creadaEn: new Date().toISOString(),
  };
  escribir([...actuales, reserva]);
  return { ok: true, reserva };
}

export function moverReserva(id: string, fecha: string, inicio: number): Resultado {
  const actuales = leer();
  const r = actuales.find((x) => x.id === id);
  if (!r || r.estado !== "confirmada") return { ok: false, error: "La reserva no está activa." };
  const error = motivoConflicto({ fecha, inicio, duracion: r.duracion }, actuales, new Date(), id);
  if (error) return { ok: false, error };
  const nueva = { ...r, fecha, inicio };
  escribir(actuales.map((x) => (x.id === id ? nueva : x)));
  return { ok: true, reserva: nueva };
}

export function cancelarReserva(id: string) {
  escribir(leer().map((x) => (x.id === id ? { ...x, estado: "cancelada" as const } : x)));
}

export function buscarReserva(codigo: string, celular: string): Reserva | undefined {
  const c = codigo.trim().toUpperCase();
  return leer().find((r) => r.codigo === c && r.celular === celular);
}

export function restablecerDatos() {
  escribir(generarDatosEjemplo(new Date()));
}

const EJEMPLOS: [number, string, string, string, string, string][] = [
  // [día hábil, hora, servicio, nombre, celular, nota]
  [0, "09:00", "arreglo", "Valentina Restrepo", "3001234501", "Bastilla de pantalón de dotación"],
  [0, "10:00", "ajuste", "Andrés Gómez", "3101234502", "Ajustar traje para la entrevista del lunes"],
  [0, "14:20", "confeccion", "Luisa Fernanda Ortiz", "3151234503", "Primera prueba de vestido de quince"],
  [1, "09:40", "arreglo", "Camilo Pardo", "3201234504", "Cambiar cremallera de chaqueta"],
  [1, "11:00", "ajuste", "Daniela Vargas", "3011234505", "Ajuste de vestido para grados"],
  [1, "15:00", "arreglo", "Jorge Iván Castaño", "3121234506", "Pegar botones de camisa blanca"],
  [2, "09:00", "confeccion", "Mariana Londoño", "3161234507", "Vestido para un matrimonio el 6 de diciembre"],
  [2, "14:00", "ajuste", "Sebastián Rincón", "3181234508", "Entallar dos camisas de oficina"],
  [3, "10:20", "arreglo", "Paula Andrea Muñoz", "3021234509", "Bastilla de jean, que quede con ruedo original"],
  [3, "16:00", "ajuste", "Natalia Herrera", "3141234510", "Subir ruedo y entallar falda de uniforme"],
  [4, "09:20", "ajuste", "Felipe Arango", "3171234511", "Ajustar saco del papá a mi talla"],
  [4, "11:40", "arreglo", "Catalina Ospina", "3041234512", "Remendar codo de buzo"],
  [5, "14:40", "confeccion", "Juliana Cárdenas", "3191234513", "Blusa en lino para viaje a Cartagena"],
  [6, "09:00", "arreglo", "Diego Alejandro Ruiz", "3111234514", "Cambiar cremallera de maleta de tela"],
  [6, "15:20", "ajuste", "Laura Sofía Mejía", "3051234515", "Ajuste de vestido de dama de honor"],
  [7, "10:00", "confeccion", "Carolina Salazar", "3131234516", "Primera prueba de pantalón palazzo"],
  [8, "11:00", "arreglo", "Santiago Quintero", "3211234517", "Bastilla de pantalón de colegio"],
  [9, "14:00", "ajuste", "Manuela Torres", "3061234518", "Ajustar chaqueta de cuero en hombros"],
  [2, "11:20", "arreglo", "Ricardo Beltrán", "3221234519", "Coser bolsillo roto de pantalón"],
  [5, "10:00", "ajuste", "Ana María Jaramillo", "3071234520", "Entallar vestido de coctel"],
];
const CANCELADAS = new Set([18, 19]);

export function generarDatosEjemplo(ahora: Date): Reserva[] {
  const manana = new Date(ahora.getTime() + 24 * 60 * 60 * 1000);
  const dias = proximosDiasHabiles(manana, 10);
  const out: Reserva[] = [];
  const codigos = new Set<string>();
  EJEMPLOS.forEach(([d, hora, sid, nombre, celular, nota], i) => {
    const s = getServicio(sid);
    const fecha = dias[d];
    if (!s || !fecha) return;
    const [h = 0, m = 0] = hora.split(":").map(Number);
    const inicio = h * 60 + m;
    const cancelada = CANCELADAS.has(i);
    if (!cancelada && motivoConflicto({ fecha: fecha, inicio, duracion: s.duracion }, out, ahora)) return;
    const codigo = generarCodigo(codigos);
    codigos.add(codigo);
    out.push({
      id: `ejemplo-${i}`,
      codigo,
      servicioId: sid,
      fecha: fecha,
      inicio,
      duracion: s.duracion,
      nombre,
      celular,
      nota,
      estado: cancelada ? "cancelada" : "confirmada",
      creadaEn: ahora.toISOString(),
    });
  });
  return out;
}

export { TALLER };
