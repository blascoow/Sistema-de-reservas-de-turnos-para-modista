// Funciones puras de disponibilidad. Única fuente de verdad para reserva pública y panel.
import { TALLER } from "@/config/taller";
import { minutosAhora, parseISODate, sumarDias, toISODate } from "@/lib/format";

export type EstadoReserva = "confirmada" | "cancelada";
export type Reserva = {
  id: string;
  codigo: string;
  servicioId: string;
  fecha: string; // YYYY-MM-DD
  inicio: number; // minutos desde medianoche
  duracion: number;
  nombre: string;
  celular: string; // 10 dígitos
  nota: string;
  estado: EstadoReserva;
  creadaEn: string;
};

type Config = Pick<typeof TALLER, "bloques" | "franjaMinutos" | "diasAbiertos">;

export function esDiaAbierto(fecha: string, cfg: Config = TALLER): boolean {
  return (cfg.diasAbiertos as readonly number[]).includes(parseISODate(fecha).getUTCDay());
}

/** Todas las franjas (inicio en minutos) del día. */
export function franjasDelDia(cfg: Config = TALLER): number[] {
  const out: number[] = [];
  for (const b of cfg.bloques) for (let t = b.inicio; t < b.fin; t += cfg.franjaMinutos) out.push(t);
  return out;
}

export function franjasOcupadas(
  reservas: Reserva[],
  fecha: string,
  excluirId?: string,
  cfg: Config = TALLER,
): Set<number> {
  const s = new Set<number>();
  for (const r of reservas) {
    if (r.estado !== "confirmada" || r.fecha !== fecha || r.id === excluirId) continue;
    for (let t = r.inicio; t < r.inicio + r.duracion; t += cfg.franjaMinutos) s.add(t);
  }
  return s;
}

/** Comprobación central: devuelve un motivo si el turno no es válido, o null si se puede guardar. */
export function motivoConflicto(
  cand: { fecha: string; inicio: number; duracion: number },
  reservas: Reserva[],
  ahora: Date,
  excluirId?: string,
  cfg: Config = TALLER,
): string | null {
  if (!esDiaAbierto(cand.fecha, cfg)) return "Ese día el taller está cerrado.";
  const hoy = toISODate(ahora);
  if (cand.fecha < hoy || (cand.fecha === hoy && cand.inicio <= minutosAhora(ahora)))
    return "Esa hora ya pasó.";
  const bloque = cfg.bloques.find((b) => cand.inicio >= b.inicio && cand.inicio + cand.duracion <= b.fin);
  if (!bloque || (cand.inicio - bloque.inicio) % cfg.franjaMinutos !== 0)
    return "El servicio no cabe en ese horario.";
  const ocupadas = franjasOcupadas(reservas, cand.fecha, excluirId, cfg);
  for (let t = cand.inicio; t < cand.inicio + cand.duracion; t += cfg.franjaMinutos)
    if (ocupadas.has(t)) return "Ese horario ya está ocupado.";
  return null;
}

export function horasInicioValidas(
  fecha: string,
  duracion: number,
  reservas: Reserva[],
  ahora: Date,
  excluirId?: string,
  cfg: Config = TALLER,
): number[] {
  return franjasDelDia(cfg).filter(
    (t) => motivoConflicto({ fecha, inicio: t, duracion }, reservas, ahora, excluirId, cfg) === null,
  );
}

/** Próximos n días hábiles empezando hoy. */
export function proximosDiasHabiles(ahora: Date, n: number, cfg: Config = TALLER): string[] {
  const out: string[] = [];
  let iso = toISODate(ahora);
  while (out.length < n) {
    if (esDiaAbierto(iso, cfg)) out.push(iso);
    iso = sumarDias(iso, 1);
  }
  return out;
}
