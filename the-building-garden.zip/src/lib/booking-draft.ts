import { TALLER, getServicio } from "@/config/taller";
import { validarDatos, DATOS_VACIOS, type Datos } from "@/components/taller/DatosForm";
import { horasInicioValidas, proximosDiasHabiles, type Reserva } from "@/lib/availability";

export const BOOKING_DRAFT_KEY = "hilvan_v1_borrador";
export type BookingDraft = { servicioId: string | null; fecha: string | null; hora: number | null; datos: Datos };
export const EMPTY_DRAFT: BookingDraft = { servicioId: null, fecha: null, hora: null, datos: DATOS_VACIOS };

export function leerBorrador(): BookingDraft {
  try {
    const d = JSON.parse(sessionStorage.getItem(BOOKING_DRAFT_KEY) ?? "null");
    if (!d || typeof d !== "object") return EMPTY_DRAFT;
    return {
      servicioId: typeof d.servicioId === "string" ? d.servicioId : null,
      fecha: typeof d.fecha === "string" && /^\d{4}-\d{2}-\d{2}$/.test(d.fecha) ? d.fecha : null,
      hora: typeof d.hora === "number" && Number.isFinite(d.hora) ? d.hora : null,
      datos: { nombre: typeof d.datos?.nombre === "string" ? d.datos.nombre : "", celular: typeof d.datos?.celular === "string" ? d.datos.celular : "", nota: typeof d.datos?.nota === "string" ? d.datos.nota : "" },
    };
  } catch { return EMPTY_DRAFT; }
}

/** Highest reachable step; save-time overlap validation remains in storage.ts. */
export function primerPasoIncompleto(d: BookingDraft, reservas: Reserva[], ahora: Date): number {
  const servicio = d.servicioId ? getServicio(d.servicioId) : undefined;
  if (!servicio) return 1;
  if (!d.fecha || !proximosDiasHabiles(ahora, TALLER.diasReservables).includes(d.fecha)) return 2;
  const horas = horasInicioValidas(d.fecha, servicio.duracion, reservas, ahora);
  if (!horas.length) return 2;
  if (d.hora === null || !horas.includes(d.hora)) return 3;
  if (Object.keys(validarDatos(d.datos)).length) return 4;
  return 5;
}