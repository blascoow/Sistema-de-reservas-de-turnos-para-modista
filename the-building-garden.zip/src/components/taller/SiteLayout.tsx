import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { TALLER } from "@/config/taller";
import { useHeaderHeight } from "@/hooks/use-header-height";

export function Stitch({ className = "" }: { className?: string }) {
  return <div aria-hidden className={`stitch ${className}`} />;
}

export function SiteLayout({ children, onReservar }: { children: ReactNode; onReservar?: () => void }) {
  const headerRef = useHeaderHeight();
  const nav = "rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground";
  const active = { className: "bg-card text-foreground shadow-soft" };
  return (
    <div className="flex min-h-screen flex-col">
      <header ref={headerRef} className="sticky top-0 z-30 border-b border-border bg-background/95 pt-[env(safe-area-inset-top)] backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-2 px-4 py-2">
          <Link to="/" className="flex min-h-11 items-center gap-2 font-serif text-lg font-semibold">
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden className="text-primary">
              <path d="M4 20 L20 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              <circle cx="18" cy="6" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
              <path d="M3 12c4-3 6 3 10 0s6 3 8 0" fill="none" stroke="currentColor" strokeWidth="1.4" strokeDasharray="2 2.5" />
            </svg>
            {TALLER.nombre}
          </Link>
          <nav className="flex items-center gap-1">
            <Link to="/reservar" search={{ paso: 1 }} onClick={onReservar} className={nav} activeProps={active}>Reservar</Link>
            <Link to="/mi-turno" search={{ codigo: "", celular: "" }} className={nav} activeProps={active}>Mi turno</Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 sm:py-10">{children}</main>
      <footer className="safe-bottom border-t border-border">
        <div className="mx-auto flex max-w-5xl flex-col gap-2 px-4 pt-6 text-sm text-muted-foreground sm:flex-row sm:justify-between">
          <p>{TALLER.nombre} · {TALLER.direccion}</p>
          <div className="flex gap-4">
            <a href={`tel:${TALLER.telefonoHref}`} className="py-2 hover:text-foreground">{TALLER.telefono}</a>
            <Link to="/admin" className="py-2 hover:text-foreground">Panel del taller</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
