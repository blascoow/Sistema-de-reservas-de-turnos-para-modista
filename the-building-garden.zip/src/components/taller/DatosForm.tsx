import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { normalizarCelular, soloCelular } from "@/lib/format";

export type Datos = { nombre: string; celular: string; nota: string };
export const DATOS_VACIOS: Datos = { nombre: "", celular: "", nota: "" };

export function validarDatos(d: Datos) {
  const errores: Partial<Record<keyof Datos, string>> = {};
  if (d.nombre.trim().length < 3) errores.nombre = "Escribe tu nombre completo.";
  else if (!/\s/.test(d.nombre.trim())) errores.nombre = "Incluye nombre y apellido.";
  if (!d.celular.trim()) errores.celular = "Necesitamos tu celular para confirmarte.";
  else if (!normalizarCelular(d.celular)) errores.celular = "Debe ser un celular colombiano de 10 dígitos que empiece por 3.";
  return errores;
}

export function DatosForm({
  value,
  onChange,
  tocados,
  onBlur,
}: {
  value: Datos;
  onChange: (d: Datos) => void;
  tocados: Partial<Record<keyof Datos, boolean>>;
  onBlur: (k: keyof Datos) => void;
}) {
  const errores = validarDatos(value);
  const err = (k: keyof Datos) => (tocados[k] ? errores[k] : undefined);
  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="nombre">Nombre completo *</Label>
        <Input id="nombre" autoComplete="name" className="min-h-11 bg-card text-base" value={value.nombre}
          aria-invalid={!!err("nombre")} onBlur={() => onBlur("nombre")}
          onChange={(e) => onChange({ ...value, nombre: e.target.value })} placeholder="Ej. Valentina Restrepo" />
        {err("nombre") && <p className="text-sm text-destructive">{err("nombre")}</p>}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="celular">Celular *</Label>
        <div className="flex">
          <span className="flex items-center rounded-l-md border border-r-0 border-input bg-muted px-3 text-sm">+57</span>
          <Input id="celular" type="tel" inputMode="numeric" autoComplete="tel-national" className="min-h-11 rounded-l-none bg-card text-base"
            value={value.celular} aria-invalid={!!err("celular")} onBlur={() => onBlur("celular")}
            onChange={(e) => onChange({ ...value, celular: soloCelular(e.target.value) })} placeholder="300 123 4567" />
        </div>
        {err("celular") && <p className="text-sm text-destructive">{err("celular")}</p>}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="nota">Nota sobre la prenda u ocasión (opcional)</Label>
        <Textarea id="nota" rows={3} className="bg-card text-base" value={value.nota} maxLength={240}
          onChange={(e) => onChange({ ...value, nota: e.target.value })}
          placeholder="Ej. vestido para un matrimonio el 6 de diciembre" />
      </div>
    </div>
  );
}
