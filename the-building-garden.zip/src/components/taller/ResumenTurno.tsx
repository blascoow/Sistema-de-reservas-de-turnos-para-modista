import { getServicio } from "@/config/taller";
import { formatCelular, formatFecha, formatHora } from "@/lib/format";

export function ResumenTurno(p: {
  servicioId: string; fecha: string; inicio: number; nombre?: string; celular?: string; nota?: string;
}) {
  const s = getServicio(p.servicioId);
  const filas: [string, string][] = [
    ["Servicio", `${s?.nombre ?? ""} (${s?.duracion} min)`],
    ["Fecha", formatFecha(p.fecha)],
    ["Hora", `${formatHora(p.inicio)} – ${formatHora(p.inicio + (s?.duracion ?? 0))}`],
  ];
  if (p.nombre) filas.push(["Nombre", p.nombre]);
  if (p.celular) filas.push(["Celular", formatCelular(p.celular)]);
  if (p.nota) filas.push(["Nota", p.nota]);
  return (
    <dl className="divide-y divide-border rounded-2xl border border-border bg-card">
      {filas.map(([k, v]) => (
        <div key={k} className="flex flex-col gap-0.5 px-4 py-3 sm:flex-row sm:gap-4">
          <dt className="w-24 shrink-0 text-sm text-muted-foreground">{k}</dt>
          <dd className="font-medium first-letter:uppercase">{v}</dd>
        </div>
      ))}
    </dl>
  );
}
