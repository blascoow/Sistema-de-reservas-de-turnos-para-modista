import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { TALLER } from "@/config/taller";
import { horasInicioValidas, proximosDiasHabiles, type Reserva } from "@/lib/availability";
import { formatDiaCorto, formatFecha, formatHora, esPasado } from "@/lib/format";
import { cn } from "@/lib/utils";

export function useDiasDisponibles(duracion: number, reservas: Reserva[], excluirId?: string) {
  return useMemo(() => {
    const ahora = new Date();
    return proximosDiasHabiles(ahora, TALLER.diasReservables).map((fecha) => ({
      fecha,
      horas: horasInicioValidas(fecha, duracion, reservas, ahora, excluirId),
    }));
  }, [duracion, reservas, excluirId]);
}

export function DayPicker({
  dias,
  value,
  onChange,
}: {
  dias: { fecha: string; horas: number[] }[];
  value: string | null;
  onChange: (f: string) => void;
}) {
  return (
    <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
      {dias.map(({ fecha, horas }) => {
        const d = formatDiaCorto(fecha);
        const lleno = horas.length === 0;
        const sel = value === fecha;
        return (
          <Button variant="ghost"
            key={fecha}
            type="button"
            disabled={lleno}
            onClick={() => onChange(fecha)}
            aria-pressed={sel}
            aria-label={`${formatFecha(fecha)}, ${lleno ? "completo" : `${horas.length} ${horas.length === 1 ? "horario libre" : "horarios libres"}`}`}
            className={cn(
              "flex h-auto min-h-11 flex-col items-center rounded-xl border px-2 py-2 text-center transition-colors",
              sel
                ? "border-secondary bg-secondary text-secondary-foreground"
                : "border-border bg-card hover:border-secondary",
              lleno && "cursor-not-allowed bg-muted opacity-60",
            )}
          >
            <span className="text-xs capitalize">{d.dia}</span>
            <span className="font-serif text-xl font-semibold leading-tight">{d.num}</span>
            <span className="text-xs">{d.mes}</span>
            <span className={cn("mt-1 text-[13px] font-medium", !sel && (lleno ? "text-muted-foreground" : "text-secondary"))}>
              {lleno ? "Completo" : `${horas.length} ${horas.length === 1 ? "libre" : "libres"}`}
            </span>
          </Button>
        );
      })}
    </div>
  );
}

export function TimePicker({
  horas,
  value,
  onChange,
  actual,
  actualPasado = false,
}: {
  actual?: number | undefined;
  actualPasado?: boolean;
  horas: number[];
  value: number | null;
  onChange: (h: number) => void;
}) {
  const grupos = [
    { titulo: "Mañana", items: horas.filter((h) => h < 12 * 60) },
    { titulo: "Tarde", items: horas.filter((h) => h >= 12 * 60) },
  ].filter((g) => g.items.length);
  return (
    <div className="space-y-4">
      {grupos.map((g) => (
        <div key={g.titulo}>
          <h4 className="mb-2 text-sm font-semibold text-muted-foreground">{g.titulo}</h4>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {g.items.map((h) => (
              <Button variant="ghost"
                key={h}
                type="button"
                onClick={() => onChange(h)}
                aria-pressed={value === h}
                disabled={actualPasado && h === actual}
                className={cn(
                  "min-h-11 h-auto flex-col whitespace-normal rounded-xl border px-2 py-2 text-sm font-medium transition-colors",
                  value === h
                    ? "border-secondary bg-secondary text-secondary-foreground"
                    : "border-border bg-card hover:border-secondary",
                )}
              >
                {formatHora(h)}
                {actual === h && <span className="text-xs">Tu turno actual</span>}
              </Button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Fecha + hora juntas, para mover o crear desde el panel y Mi turno. */
export function ScheduleSelector({
  duracion,
  reservas,
  excluirId,
  fecha,
  hora,
  onFecha,
  onHora,
  turnoActual,
}: {
  turnoActual?: { fecha: string; inicio: number };
  duracion: number;
  reservas: Reserva[];
  excluirId?: string;
  fecha: string | null;
  hora: number | null;
  onFecha: (f: string) => void;
  onHora: (h: number) => void;
}) {
  const disponibles = useDiasDisponibles(duracion, reservas, excluirId);
  const dias = turnoActual && !disponibles.some((d) => d.fecha === turnoActual.fecha)
    ? [{ fecha: turnoActual.fecha, horas: [] }, ...disponibles] : disponibles;
  const actual = turnoActual?.fecha === fecha ? turnoActual.inicio : undefined;
  const horasValidas = dias.find((d) => d.fecha === fecha)?.horas ?? [];
  const horas = actual !== undefined && !horasValidas.includes(actual) ? [...horasValidas, actual].sort((a, b) => a - b) : horasValidas;
  return (
    <div className="space-y-5">
      <div>
        <h4 className="mb-2 text-sm font-semibold">Fecha</h4>
        <div className="max-h-64 overflow-y-auto pr-1">
          <DayPicker dias={dias} value={fecha} onChange={onFecha} />
        </div>
      </div>
      {fecha && (
        <div>
          <h4 className="mb-2 text-sm font-semibold">Hora · {formatFecha(fecha)}</h4>
          <TimePicker horas={horas} value={hora} onChange={onHora} actual={actual} actualPasado={actual !== undefined && !!fecha && esPasado(fecha, actual)} />
        </div>
      )}
    </div>
  );
}
