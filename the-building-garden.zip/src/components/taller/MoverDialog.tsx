import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScheduleSelector } from "@/components/taller/Schedule";
import { getServicio } from "@/config/taller";
import type { Reserva } from "@/lib/availability";
import { formatFecha, formatHora } from "@/lib/format";
import { moverReserva, useReservas } from "@/lib/storage";

export function MoverDialog({ reserva, trigger }: { reserva: Reserva; trigger: ReactNode }) {
  const reservas = useReservas();
  const [open, setOpen] = useState(false);
  const [fecha, setFecha] = useState<string | null>(null);
  const [hora, setHora] = useState<number | null>(null);
  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o) { setFecha(reserva.fecha); setHora(reserva.inicio); } }}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-h-[90dvh] overflow-y-auto bg-card">
        <DialogHeader>
          <DialogTitle className="font-serif">Cambiar fecha u hora</DialogTitle>
          <DialogDescription>
            {getServicio(reserva.servicioId)?.nombre} · ahora el {formatFecha(reserva.fecha)} a las {formatHora(reserva.inicio)}
          </DialogDescription>
        </DialogHeader>
        <ScheduleSelector duracion={reserva.duracion} reservas={reservas} excluirId={reserva.id}
          turnoActual={reserva} fecha={fecha} hora={hora} onFecha={(f) => { setFecha(f); setHora(null); }} onHora={setHora} />
        <Button disabled={!fecha || hora === null} onClick={() => {
          if (!fecha || hora === null) return;
          const r = moverReserva(reserva.id, fecha, hora);
          if (!r.ok) { toast.error(r.error); return; }
          toast.success(`Turno movido al ${formatFecha(fecha)} a las ${formatHora(hora)}.`);
          setOpen(false);
        }}>Guardar cambio</Button>
      </DialogContent>
    </Dialog>
  );
}
