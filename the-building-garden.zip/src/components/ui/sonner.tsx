import { Toaster as Sonner } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      containerAriaLabel="Avisos"
      hotkey={[]}
      offset="calc(var(--app-header-height, 0px) + 12px)"
      mobileOffset={{ top: "calc(var(--app-header-height, 0px) + 12px)", left: "16px", right: "16px" }}
      toastOptions={{
        closeButtonAriaLabel: "Cerrar",
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };
