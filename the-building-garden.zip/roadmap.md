# Correcciones solicitadas
- [x] Reinicio, historial y borrador de reservas; Mi turno prerrellenado.
- [x] Avisos, textos, celular, búsqueda y reprogramación.
- [x] Agenda pasada, navegación pública y zona horaria colombiana.
- [x] Documentar limitaciones; 15 pruebas y verificación pública y del panel en celular y escritorio.
