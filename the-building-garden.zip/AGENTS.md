<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Taller Hilván
- All shop settings (name, hours, slot size, services, admin password) live in `src/config/taller.ts`; never hardcode them elsewhere so the demo stays reconfigurable.
- Availability rules are pure functions in `src/lib/availability.ts`; `motivoConflicto` is the single overlap check used by public booking, Mi turno and admin, and is re-run in `src/lib/storage.ts` right before every save.
- No backend by design: persistence is localStorage via `src/lib/storage.ts` (`useReservas` store); date-dependent routes use `ssr: false` to avoid hydration mismatches.
- Booking steps use validated URL search state and a sessionStorage draft; confirmation clears the draft while storage.ts remains the only reservation writer.
- Date-only calendar arithmetic uses UTC getters and ISO strings; real instants are converted through the configured shop timezone before all past/availability checks.
- Public and admin headers share a ResizeObserver measurement for the toast offset so notifications never cover navigation.
