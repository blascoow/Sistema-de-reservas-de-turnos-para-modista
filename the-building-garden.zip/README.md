# Taller Hilván · Reservas de turnos (demo)

Aplicación web para que los clientes de un taller de costura vean la disponibilidad real y reserven su turno, y la modista gestione la agenda desde un panel con clave.

- `/` inicio · `/reservar` reserva en 5 pasos · `/mi-turno` consultar, cambiar o cancelar con código + celular · `/admin` panel del taller.

## Arrancar en local

```bash
npm install
npm run dev
```

## Qué está simulado

- **Sin backend**: todo se guarda en el `localStorage` del navegador.
- **Recordatorio por WhatsApp** y confirmaciones: solo muestran un mensaje en pantalla.
- **Datos de ejemplo**: unas 20 reservas en los próximos 10 días hábiles, calculadas a partir de la fecha actual.

## Reiniciar los datos de ejemplo

- En el panel `/admin`, botón **Restablecer datos de ejemplo**.
- O borra en el navegador la clave de `localStorage` **`hilvan_v1_reservas`** (la sesión del panel vive en `sessionStorage` como `hilvan_v1_admin`).

## Cambiar la clave del panel

Archivo `src/config/taller.ts`, constante `TALLER.claveAdmin` (por defecto `"taller2026"`).
Es una protección **solo de demo**: la clave viaja en el código del navegador y no ofrece seguridad real hasta que se integre un backend con autenticación.

## Cambiar nombre, horario y servicios

Todo en `src/config/taller.ts`: `nombre`, `lema`, `direccion`, `telefono`, `diasAbiertos`, `bloques` (minutos desde medianoche), `franjaMinutos` y la lista `servicios` (la duración debe ser múltiplo de la franja).

## Pruebas

`bunx vitest run` comprueba las reglas de disponibilidad (`src/lib/availability.ts`).


## Limitaciones de esta demo

- Los datos se guardan **solo en localStorage del navegador que se usa**. Las reservas de un dispositivo no aparecen en otro y el control de solapes solo funciona dentro de un mismo navegador. Es lo previsto en el encargo: **Kodarvia integra el backend, las políticas y el despliegue**. Esta demo no proporciona coordinación de reservas entre dispositivos ni garantías ante escrituras simultáneas de varias pestañas.
- La clave del panel (`taller2026`, configurable en `src/config/taller.ts`) viaja en el código del cliente. La sesión es una marca en sessionStorage, no una autenticación. Ambas deben sustituirse por autenticación real al integrar el backend.
- **localStorage:** `hilvan_v1_reservas` contiene las reservas.
- **sessionStorage:** `hilvan_v1_admin` contiene la marca de sesión del panel; `hilvan_v1_borrador` conserva servicio, fecha, hora y datos del formulario durante los cinco pasos. Se elimina al confirmar o iniciar otra reserva.
- Para reiniciar todo, abre las herramientas del navegador → Aplicación/Almacenamiento y elimina esas tres claves para este sitio; después recarga. Al borrar las reservas se vuelven a cargar los ejemplos. También puedes ejecutar en la consola del sitio:

```javascript
localStorage.removeItem("hilvan_v1_reservas");
sessionStorage.removeItem("hilvan_v1_admin");
sessionStorage.removeItem("hilvan_v1_borrador");
location.reload();
```

Las fechas, el día actual y las horas pasadas se calculan con `TALLER.zonaHoraria` (`America/Bogota`), no con la zona horaria del dispositivo. Los pasos usan `/reservar?paso=1` a `paso=5`, con atrás/adelante del navegador y borrador en sessionStorage.
